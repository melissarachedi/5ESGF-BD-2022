﻿using System;

namespace SudokuSolver
{
    class Program
    {
        public static bool isVeilig(int[,] board, int row, int col, int num)
        {
            //Vérifier si le numéro est unique sur les lignes
            for (int i = 0; i < board.GetLength(0); i++)
                if (board[row, i] == num) // Retourner "False" si le nombre se répète
                    return false;

            //Vérifier si le numéro est unique sur les colonnes
            for (int i = 0; i < board.GetLength(0); i++)
                if (board[i, col] == num) // Retourner "False" si le nombre se répète
                    return false;

            //Vérifier s'il y a une correspondance dans la matrice (3x3)
            int squareroot = (int)Math.Sqrt(board.GetLength(0));
            int rowStart = row - row % squareroot;
            int colStart = col - col % squareroot;

            for (int i = rowStart; i < rowStart + squareroot; i++)
                for (int j = colStart; j < colStart + squareroot; j++)
                    if (board[i, j] == num)
                        return false; //Non sécurisé

            
            return true;
        }

        public static bool losOp(int[,] board, int n)
        {
            int row = 0;
            int col = 0;

            bool isEmpty = true; //La case est vide par défaut

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++) //Deux boucles for pour scanner l'ensemble du tableau
                {
                    if (board[i, j] == 0) //Vérifier si la case est déjà rempli
                    {
                        row = i; //Sera nécessaire plus tard pour le traitement
                        col = j; //Sera nécessaire plus tard pour le traitement

                        // Des cases encore vide dans le jeu

                        isEmpty = false; //La matrice n'est plus vide
                        break;
                    }
                }
                if (!isEmpty) //Si la case est déjà rempli, passer à la case suivante
                {
                    break;
                }
            }

            // Entiérement résolu
            if (isEmpty) //Si le sudoku est complètement résolu, retourner "True"
            {
                return true;
            }


            for (int num = 1; num <= n; num++)
            {
                if (isVeilig(board, row, col, num)) //Vérification
                {
                    board[row, col] = num; //Remplir la case
                    if (losOp(board, n)) //Si le tableau est complètement rempli, retourner "True"
                    {
                        return true;
                    }
                    else
                    {
                        board[row, col] = 0; // Pas bon, il faut remplacer
                    }
                }
            }
            return false;
        }

        public static void printOplossing(int[,] board, int N)
        {
            //Affichage à l'écran
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    Console.Write(board[i, j]);
                    Console.Write(" ");
                }
                Console.Write("\n");

                if ((i + 1) % (int)Math.Sqrt(N) == 0)
                {
                    Console.Write("");
                }
            }
        }

        public static void Main(String[] args)
        {

            int[,] board = new int[,] //Créer un tableau
            {
            {4, 0, 0, 0, 0, 8, 0, 0, 0},
            {7, 0, 8, 4, 2, 0, 0, 0, 5},
            {0, 0, 0, 9, 0, 0, 0, 1, 0},
            {9, 0, 0, 0, 0, 3, 0, 2, 0},
            {0, 0, 0, 0, 1, 0, 0, 0, 0},
            {0, 7, 0, 8, 0, 0, 0, 0, 9},
            {0, 5, 0, 0, 0, 4, 0, 0, 0},
            {0, 0, 0, 5, 0, 0, 0, 0, 6}
            };

            int N = board.GetLength(0); //Longueur

            if (losOp(board, N))
                printOplossing(board, N);
            else
                Console.Write("Geen oplossing");
        }
    }
}
